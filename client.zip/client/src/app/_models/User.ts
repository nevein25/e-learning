// the logedin user, i retyrn those info in login, maybe this is so general?
export interface User{
    username: string;
    email: string;
    token: string;
}