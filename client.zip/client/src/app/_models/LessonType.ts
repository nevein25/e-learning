export enum LessonType {
    Text = '0',
    Video = '1'
  }