export interface UserLogin{
    emailOrUsername:string;
    password:string;
}